import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export interface SessionUser {
  id: string
  email: string
  name?: string
  phone?: string
  avatar?: string
  isActive: boolean
  createdAt: string
  updatedAt: string
  roles: Array<{
    role: {
      id: string
      name: string
      description?: string
      permissions: string[]
      isSystem: boolean
      isActive: boolean
    }
  }>
  branches: Array<{
    branch: {
      id: string
      name: string
      address: string
      isActive: boolean
    }
  }>
}

export async function getSession(request: NextRequest): Promise<SessionUser | null> {
  try {
    const sessionCookie = request.cookies.get('session')
    if (!sessionCookie) return null

    const sessionData = JSON.parse(sessionCookie.value)
    return sessionData as SessionUser
  } catch (error) {
    return null
  }
}

export async function requireAuth(request: NextRequest): Promise<NextResponse | SessionUser> {
  const user = await getSession(request)
  if (!user) {
    return NextResponse.json(
      { error: 'Authentication required' },
      { status: 401 }
    )
  }
  return user
}

export function hasPermission(user: SessionUser, permission: string): boolean {
  return user.roles.some(userRole => 
    userRole.role.permissions.includes(permission)
  )
}

export async function requirePermission(
  request: NextRequest, 
  permission: string
): Promise<NextResponse | SessionUser> {
  const authResult = await requireAuth(request)
  if (authResult instanceof NextResponse) {
    return authResult
  }

  const user = authResult as SessionUser
  if (!hasPermission(user, permission)) {
    return NextResponse.json(
      { error: 'Insufficient permissions' },
      { status: 403 }
    )
  }

  return user
}

export async function requireRole(
  request: NextRequest, 
  roleName: string
): Promise<NextResponse | SessionUser> {
  const authResult = await requireAuth(request)
  if (authResult instanceof NextResponse) {
    return authResult
  }

  const user = authResult as SessionUser
  const hasRole = user.roles.some(userRole => 
    userRole.role.name === roleName
  )

  if (!hasRole) {
    return NextResponse.json(
      { error: 'Insufficient role privileges' },
      { status: 403 }
    )
  }

  return user
}

export async function getActiveBranch(request: NextRequest): Promise<string | null> {
  const user = await getSession(request)
  if (!user || !user.branches.length) return null

  // For now, return the first active branch
  // In a real app, this might be stored in session or determined by context
  const activeBranch = user.branches.find(ub => ub.branch.isActive)
  return activeBranch?.branch.id || null
}