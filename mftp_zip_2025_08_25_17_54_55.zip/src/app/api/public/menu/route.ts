import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

// GET /api/public/menu - Get menu for QR code access
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const branchId = searchParams.get('branchId')
    const tableId = searchParams.get('tableId')

    if (!branchId) {
      return NextResponse.json(
        { error: 'Branch ID required' },
        { status: 400 }
      )
    }

    // Verify branch exists and is active
    const branch = await db.branch.findUnique({
      where: { 
        id: branchId,
        isActive: true 
      },
      include: {
        restaurant: {
          select: {
            id: true,
            name: true,
            logo: true,
            description: true
          }
        }
      }
    })

    if (!branch) {
      return NextResponse.json(
        { error: 'Branch not found or inactive' },
        { status: 404 }
      )
    }

    // Verify table exists if provided
    let table = null
    if (tableId) {
      table = await db.table.findUnique({
        where: { 
          id: tableId,
          branchId,
          isActive: true 
        }
      })

      if (!table) {
        return NextResponse.json(
          { error: 'Table not found or inactive' },
          { status: 404 }
        )
      }
    }

    // Get categories with menu items
    const categories = await db.category.findMany({
      where: {
        branchId,
        isActive: true
      },
      include: {
        menuItems: {
          where: {
            isActive: true,
            isAvailable: true
          },
          include: {
            variations: {
              where: { isActive: true },
              orderBy: { createdAt: 'asc' }
            },
            addons: {
              where: { isActive: true },
              orderBy: { createdAt: 'asc' }
            }
          },
          orderBy: [
            { sortOrder: 'asc' },
            { createdAt: 'asc' }
          ]
        }
      },
      orderBy: [
        { sortOrder: 'asc' },
        { createdAt: 'asc' }
      ]
    })

    // Filter out empty categories
    const nonEmptyCategories = categories.filter(category => category.menuItems.length > 0)

    // Get branch settings
    const settings = branch.settings as any || {}

    return NextResponse.json({
      branch: {
        id: branch.id,
        name: branch.name,
        description: branch.description,
        address: branch.address,
        phone: branch.phone,
        email: branch.email
      },
      restaurant: branch.restaurant,
      table: table ? {
        id: table.id,
        number: table.number,
        capacity: table.capacity
      } : null,
      categories: nonEmptyCategories,
      settings: {
        currency: settings.currency || 'BDT',
        language: settings.language || 'en',
        allowGuestOrders: settings.allowGuestOrders !== false,
        requireCustomerInfo: settings.requireCustomerInfo || false,
        enableServiceRequests: settings.enableServiceRequests !== false
      }
    })
  } catch (error) {
    console.error('Get public menu error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// POST /api/public/menu - Submit guest order
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { 
      branchId, 
      tableId, 
      customerName, 
      customerPhone, 
      items, 
      notes 
    } = body

    if (!branchId || !items || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json(
        { error: 'Branch ID and items are required' },
        { status: 400 }
      )
    }

    // Verify branch exists and is active
    const branch = await db.branch.findUnique({
      where: { 
        id: branchId,
        isActive: true 
      }
    })

    if (!branch) {
      return NextResponse.json(
        { error: 'Branch not found or inactive' },
        { status: 404 }
      )
    }

    // Check if guest orders are allowed
    const settings = branch.settings as any || {}
    if (settings.allowGuestOrders === false) {
      return NextResponse.json(
        { error: 'Guest orders are not allowed' },
        { status: 403 }
      )
    }

    // Verify table exists if provided
    if (tableId) {
      const table = await db.table.findUnique({
        where: { 
          id: tableId,
          branchId,
          isActive: true 
        }
      })

      if (!table) {
        return NextResponse.json(
          { error: 'Table not found or inactive' },
          { status: 404 }
        )
      }
    }

    // Validate items and calculate total
    let totalAmount = 0
    const orderItems = []

    for (const itemData of items) {
      if (!itemData.itemId || !itemData.quantity || itemData.quantity <= 0) {
        return NextResponse.json(
          { error: 'Invalid item data' },
          { status: 400 }
        )
      }

      const menuItem = await db.menuItem.findFirst({
        where: {
          id: itemData.itemId,
          branchId,
          isActive: true,
          isAvailable: true
        }
      })

      if (!menuItem) {
        return NextResponse.json(
          { error: `Menu item not found or unavailable: ${itemData.itemId}` },
          { status: 404 }
        )
      }

      let unitPrice = menuItem.price

      // Check variation if provided
      if (itemData.variationId) {
        const variation = await db.itemVariation.findFirst({
          where: {
            id: itemData.variationId,
            itemId: itemData.itemId,
            isActive: true
          }
        })

        if (!variation) {
          return NextResponse.json(
            { error: `Variation not found or unavailable: ${itemData.variationId}` },
            { status: 404 }
          )
        }

        unitPrice = variation.price
      }

      const totalPrice = unitPrice * itemData.quantity
      totalAmount += totalPrice

      orderItems.push({
        itemId: itemData.itemId,
        variationId: itemData.variationId,
        quantity: itemData.quantity,
        unitPrice,
        totalPrice,
        notes: itemData.notes,
        addons: itemData.addons || []
      })
    }

    // Create the order
    const order = await db.order.create({
      data: {
        branchId,
        tableId,
        customerName,
        customerPhone,
        totalAmount,
        currency: settings.currency || 'BDT',
        notes,
        items: {
          create: orderItems
        }
      },
      include: {
        branch: {
          select: {
            id: true,
            name: true
          }
        },
        table: {
          select: {
            id: true,
            number: true
          }
        },
        items: {
          include: {
            item: {
              select: {
                id: true,
                name: true,
                price: true
              }
            },
            variation: {
              select: {
                id: true,
                name: true,
                price: true
              }
            }
          }
        }
      }
    })

    // TODO: Emit real-time notification via Socket.IO
    // This would notify staff about the new order

    return NextResponse.json({
      message: 'Order placed successfully',
      order: {
        id: order.id,
        status: order.status,
        totalAmount: order.totalAmount,
        currency: order.currency,
        createdAt: order.createdAt
      }
    })
  } catch (error) {
    console.error('Create guest order error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}