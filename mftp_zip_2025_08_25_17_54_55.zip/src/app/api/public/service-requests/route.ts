import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const serviceRequestSchema = z.object({
  branchId: z.string(),
  tableId: z.string().optional(),
  type: z.enum(['CALL_WAITER', 'REQUEST_BILL', 'WATER_REQUEST', 'CLEANING_REQUEST', 'OTHER']),
  notes: z.string().optional()
})

// POST /api/public/service-requests - Create service request from guest
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const data = serviceRequestSchema.parse(body)

    if (!data.branchId) {
      return NextResponse.json(
        { error: 'Branch ID required' },
        { status: 400 }
      )
    }

    // Verify branch exists and is active
    const branch = await db.branch.findUnique({
      where: { 
        id: data.branchId,
        isActive: true 
      }
    })

    if (!branch) {
      return NextResponse.json(
        { error: 'Branch not found or inactive' },
        { status: 404 }
      )
    }

    // Check if service requests are enabled
    const settings = branch.settings as any || {}
    if (settings.enableServiceRequests === false) {
      return NextResponse.json(
        { error: 'Service requests are not enabled' },
        { status: 403 }
      )
    }

    // Verify table exists if provided
    if (data.tableId) {
      const table = await db.table.findUnique({
        where: { 
          id: data.tableId,
          branchId: data.branchId,
          isActive: true 
        }
      })

      if (!table) {
        return NextResponse.json(
          { error: 'Table not found or inactive' },
          { status: 404 }
        )
      }
    }

    const serviceRequest = await db.serviceRequest.create({
      data: {
        branchId: data.branchId,
        tableId: data.tableId,
        type: data.type,
        notes: data.notes
        // userId is null for guest requests
      },
      include: {
        branch: {
          select: {
            id: true,
            name: true
          }
        },
        table: {
          select: {
            id: true,
            number: true
          }
        }
      }
    })

    // TODO: Emit real-time notification via Socket.IO
    // This would notify staff about the new service request

    return NextResponse.json({
      message: 'Service request created successfully',
      serviceRequest: {
        id: serviceRequest.id,
        type: serviceRequest.type,
        status: serviceRequest.status,
        notes: serviceRequest.notes,
        createdAt: serviceRequest.createdAt
      }
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid input', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Create guest service request error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}