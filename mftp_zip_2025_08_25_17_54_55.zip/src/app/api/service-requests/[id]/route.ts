import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requirePermission } from '@/lib/auth'

// PATCH /api/service-requests/[id] - Update service request status
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requirePermission(request, 'service:write')
    if (user instanceof NextResponse) return user

    const body = await request.json()
    const { status } = body

    if (!status || !['PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'].includes(status)) {
      return NextResponse.json(
        { error: 'Invalid status' },
        { status: 400 }
      )
    }

    const serviceRequest = await db.serviceRequest.findUnique({
      where: { id: params.id },
      include: {
        branch: true
      }
    })

    if (!serviceRequest) {
      return NextResponse.json(
        { error: 'Service request not found' },
        { status: 404 }
      )
    }

    // Check if user has access to this branch
    const userBranchIds = user.branches.map(ub => ub.branch.id)
    if (!userBranchIds.includes(serviceRequest.branchId) && !hasPermission(user, 'service:write:all')) {
      return NextResponse.json(
        { error: 'Insufficient permissions for this branch' },
        { status: 403 }
      )
    }

    const updatedServiceRequest = await db.serviceRequest.update({
      where: { id: params.id },
      data: { status },
      include: {
        branch: {
          select: {
            id: true,
            name: true
          }
        },
        table: {
          select: {
            id: true,
            number: true
          }
        },
        user: {
          select: {
            id: true,
            name: true
          }
        }
      }
    })

    // TODO: Emit real-time notification via Socket.IO
    // This would notify about the status change

    return NextResponse.json({
      message: 'Service request updated successfully',
      serviceRequest: updatedServiceRequest
    })
  } catch (error) {
    console.error('Update service request error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// Helper function to check permissions
function hasPermission(user: any, permission: string): boolean {
  return user.roles.some((userRole: any) => 
    userRole.role.permissions.includes(permission)
  )
}