import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requirePermission, getActiveBranch } from '@/lib/auth'
import { z } from 'zod'

const serviceRequestSchema = z.object({
  branchId: z.string(),
  tableId: z.string().optional(),
  type: z.enum(['CALL_WAITER', 'REQUEST_BILL', 'WATER_REQUEST', 'CLEANING_REQUEST', 'OTHER']),
  notes: z.string().optional()
})

// GET /api/service-requests - List service requests
export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request)
    if (user instanceof NextResponse) return user

    const { searchParams } = new URL(request.url)
    const branchId = searchParams.get('branchId') || await getActiveBranch(request)
    const tableId = searchParams.get('tableId')
    const type = searchParams.get('type')
    const status = searchParams.get('status')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')

    if (!branchId) {
      return NextResponse.json(
        { error: 'Branch ID required' },
        { status: 400 }
      )
    }

    // Check if user has access to this branch
    const userBranchIds = user.branches.map(ub => ub.branch.id)
    if (!userBranchIds.includes(branchId) && !hasPermission(user, 'service:read:all')) {
      return NextResponse.json(
        { error: 'Insufficient permissions for this branch' },
        { status: 403 }
      )
    }

    const skip = (page - 1) * limit
    const where: any = { branchId }
    
    if (tableId) where.tableId = tableId
    if (type) where.type = type
    if (status) where.status = status

    const [serviceRequests, total] = await Promise.all([
      db.serviceRequest.findMany({
        where,
        include: {
          branch: {
            select: {
              id: true,
              name: true
            }
          },
          table: {
            select: {
              id: true,
              number: true,
              capacity: true
            }
          },
          user: {
            select: {
              id: true,
              name: true,
              email: true
            }
          }
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' }
      }),
      db.serviceRequest.count({ where })
    ])

    return NextResponse.json({
      serviceRequests,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('Get service requests error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// POST /api/service-requests - Create service request
export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth(request)
    if (user instanceof NextResponse) return user

    const body = await request.json()
    const data = serviceRequestSchema.parse(body)

    if (!data.branchId) {
      return NextResponse.json(
        { error: 'Branch ID required' },
        { status: 400 }
      )
    }

    // Check if user has access to this branch
    const userBranchIds = user.branches.map(ub => ub.branch.id)
    if (!userBranchIds.includes(data.branchId) && !hasPermission(user, 'service:write:all')) {
      return NextResponse.json(
        { error: 'Insufficient permissions for this branch' },
        { status: 403 }
      )
    }

    // Verify table belongs to branch if provided
    if (data.tableId) {
      const table = await db.table.findFirst({
        where: {
          id: data.tableId,
          branchId: data.branchId
        }
      })

      if (!table) {
        return NextResponse.json(
          { error: 'Table not found in this branch' },
          { status: 404 }
        )
      }
    }

    const serviceRequest = await db.serviceRequest.create({
      data: {
        branchId: data.branchId,
        tableId: data.tableId,
        type: data.type,
        notes: data.notes,
        userId: user.id
      },
      include: {
        branch: {
          select: {
            id: true,
            name: true
          }
        },
        table: {
          select: {
            id: true,
            number: true
          }
        },
        user: {
          select: {
            id: true,
            name: true
          }
        }
      }
    })

    // TODO: Emit real-time notification via Socket.IO
    // This would notify staff about the new service request

    return NextResponse.json({
      message: 'Service request created successfully',
      serviceRequest
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid input', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Create service request error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// PATCH /api/service-requests/[id] - Update service request status
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requirePermission(request, 'service:write')
    if (user instanceof NextResponse) return user

    const body = await request.json()
    const { status } = body

    if (!status || !['PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'].includes(status)) {
      return NextResponse.json(
        { error: 'Invalid status' },
        { status: 400 }
      )
    }

    const serviceRequest = await db.serviceRequest.findUnique({
      where: { id: params.id },
      include: {
        branch: true
      }
    })

    if (!serviceRequest) {
      return NextResponse.json(
        { error: 'Service request not found' },
        { status: 404 }
      )
    }

    // Check if user has access to this branch
    const userBranchIds = user.branches.map(ub => ub.branch.id)
    if (!userBranchIds.includes(serviceRequest.branchId) && !hasPermission(user, 'service:write:all')) {
      return NextResponse.json(
        { error: 'Insufficient permissions for this branch' },
        { status: 403 }
      )
    }

    const updatedServiceRequest = await db.serviceRequest.update({
      where: { id: params.id },
      data: { status },
      include: {
        branch: {
          select: {
            id: true,
            name: true
          }
        },
        table: {
          select: {
            id: true,
            number: true
          }
        },
        user: {
          select: {
            id: true,
            name: true
          }
        }
      }
    })

    // TODO: Emit real-time notification via Socket.IO
    // This would notify about the status change

    return NextResponse.json({
      message: 'Service request updated successfully',
      serviceRequest: updatedServiceRequest
    })
  } catch (error) {
    console.error('Update service request error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// Helper function to check permissions
function hasPermission(user: any, permission: string): boolean {
  return user.roles.some((userRole: any) => 
    userRole.role.permissions.includes(permission)
  )
}