import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requirePermission } from '@/lib/auth'
import { z } from 'zod'

const restaurantSchema = z.object({
  name: z.string().min(2),
  description: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email().optional(),
  website: z.string().url().optional(),
  address: z.string().optional(),
  settings: z.object({}).optional()
})

// GET /api/restaurants - List restaurants
export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request)
    if (user instanceof NextResponse) return user

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const search = searchParams.get('search') || ''

    const skip = (page - 1) * limit

    // Build where clause
    const where = search
      ? {
          OR: [
            { name: { contains: search, mode: 'insensitive' } },
            { description: { contains: search, mode: 'insensitive' } }
          ]
        }
      : {}

    // If user is not super admin, only show restaurants they have access to
    if (!hasPermission(user, 'restaurant:read:all')) {
      const userBranchIds = user.branches.map(ub => ub.branch.id)
      where['branches'] = {
        some: {
          id: { in: userBranchIds }
        }
      }
    }

    const [restaurants, total] = await Promise.all([
      db.restaurant.findMany({
        where,
        include: {
          branches: {
            select: {
              id: true,
              name: true,
              address: true,
              isActive: true
            }
          },
          themes: {
            select: {
              id: true,
              name: true,
              isDefault: true
            }
          },
          _count: {
            select: {
              branches: true,
              themes: true
            }
          }
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' }
      }),
      db.restaurant.count({ where })
    ])

    return NextResponse.json({
      restaurants,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('Get restaurants error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// POST /api/restaurants - Create restaurant
export async function POST(request: NextRequest) {
  try {
    const user = await requirePermission(request, 'restaurant:write')
    if (user instanceof NextResponse) return user

    const body = await request.json()
    const validatedData = restaurantSchema.parse(body)

    const restaurant = await db.restaurant.create({
      data: {
        name: validatedData.name,
        description: validatedData.description,
        phone: validatedData.phone,
        email: validatedData.email,
        website: validatedData.website,
        address: validatedData.address,
        settings: validatedData.settings || {}
      },
      include: {
        branches: true,
        themes: true
      }
    })

    return NextResponse.json({
      message: 'Restaurant created successfully',
      restaurant
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid input', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Create restaurant error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// Helper function to check permissions
function hasPermission(user: any, permission: string): boolean {
  return user.roles.some((userRole: any) => 
    userRole.role.permissions.includes(permission)
  )
}