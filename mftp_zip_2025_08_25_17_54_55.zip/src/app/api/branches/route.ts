import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requirePermission, getActiveBranch } from '@/lib/auth'
import { z } from 'zod'

const branchSchema = z.object({
  restaurantId: z.string(),
  name: z.string().min(2),
  description: z.string().optional(),
  address: z.string().min(5),
  phone: z.string().optional(),
  email: z.string().email().optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  settings: z.object({}).optional()
})

// GET /api/branches - List branches
export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request)
    if (user instanceof NextResponse) return user

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const search = searchParams.get('search') || ''
    const restaurantId = searchParams.get('restaurantId')

    const skip = (page - 1) * limit

    // Build where clause
    const where: any = {}
    
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { address: { contains: search, mode: 'insensitive' } }
      ]
    }

    if (restaurantId) {
      where.restaurantId = restaurantId
    }

    // If user is not super admin, only show branches they have access to
    if (!hasPermission(user, 'branch:read:all')) {
      const userBranchIds = user.branches.map(ub => ub.branch.id)
      where.id = { in: userBranchIds }
    }

    const [branches, total] = await Promise.all([
      db.branch.findMany({
        where,
        include: {
          restaurant: {
            select: {
              id: true,
              name: true
            }
          },
          tables: {
            select: {
              id: true,
              number: true,
              capacity: true,
              isActive: true
            }
          },
          categories: {
            select: {
              id: true,
              name: true,
              isActive: true
            }
          },
          branchTheme: {
            include: {
              theme: true
            }
          },
          _count: {
            select: {
              tables: true,
              categories: true,
              orders: true,
              users: true
            }
          }
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' }
      }),
      db.branch.count({ where })
    ])

    return NextResponse.json({
      branches,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('Get branches error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// POST /api/branches - Create branch
export async function POST(request: NextRequest) {
  try {
    const user = await requirePermission(request, 'branch:write')
    if (user instanceof NextResponse) return user

    const body = await request.json()
    const validatedData = branchSchema.parse(body)

    // Check if user has access to the restaurant
    if (!hasPermission(user, 'restaurant:write') && !hasPermission(user, 'branch:write:all')) {
      const userRestaurantIds = user.branches.map(ub => ub.branch.restaurantId)
      if (!userRestaurantIds.includes(validatedData.restaurantId)) {
        return NextResponse.json(
          { error: 'Insufficient permissions for this restaurant' },
          { status: 403 }
        )
      }
    }

    const branch = await db.branch.create({
      data: {
        restaurantId: validatedData.restaurantId,
        name: validatedData.name,
        description: validatedData.description,
        address: validatedData.address,
        phone: validatedData.phone,
        email: validatedData.email,
        latitude: validatedData.latitude,
        longitude: validatedData.longitude,
        settings: validatedData.settings || {}
      },
      include: {
        restaurant: true,
        tables: true,
        categories: true,
        branchTheme: {
          include: {
            theme: true
          }
        }
      }
    })

    // Create default categories for the branch
    await db.category.createMany({
      data: [
        { branchId: branch.id, name: 'Appetizers', sortOrder: 1 },
        { branchId: branch.id, name: 'Main Courses', sortOrder: 2 },
        { branchId: branch.id, name: 'Desserts', sortOrder: 3 },
        { branchId: branch.id, name: 'Beverages', sortOrder: 4 }
      ]
    })

    return NextResponse.json({
      message: 'Branch created successfully',
      branch
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid input', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Create branch error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// Helper function to check permissions
function hasPermission(user: any, permission: string): boolean {
  return user.roles.some((userRole: any) => 
    userRole.role.permissions.includes(permission)
  )
}