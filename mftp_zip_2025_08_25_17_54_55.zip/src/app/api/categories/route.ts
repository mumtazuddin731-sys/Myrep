import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requirePermission, getActiveBranch } from '@/lib/auth'
import { z } from 'zod'

const categorySchema = z.object({
  name: z.string().min(2),
  description: z.string().optional(),
  image: z.string().url().optional(),
  sortOrder: z.number().min(0).default(0),
  isActive: z.boolean().default(true)
})

// GET /api/categories - List categories
export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request)
    if (user instanceof NextResponse) return user

    const { searchParams } = new URL(request.url)
    const branchId = searchParams.get('branchId') || await getActiveBranch(request)
    const includeInactive = searchParams.get('includeInactive') === 'true'
    const search = searchParams.get('search') || ''

    if (!branchId) {
      return NextResponse.json(
        { error: 'Branch ID required' },
        { status: 400 }
      )
    }

    // Check if user has access to this branch
    const userBranchIds = user.branches.map(ub => ub.branch.id)
    if (!userBranchIds.includes(branchId) && !hasPermission(user, 'category:read:all')) {
      return NextResponse.json(
        { error: 'Insufficient permissions for this branch' },
        { status: 403 }
      )
    }

    const where: any = { branchId }
    
    if (search) {
      where.name = { contains: search, mode: 'insensitive' }
    }

    if (!includeInactive) {
      where.isActive = true
    }

    const categories = await db.category.findMany({
      where,
      include: {
        menuItems: {
          where: { isActive: true },
          select: {
            id: true,
            name: true,
            price: true,
            isAvailable: true,
            sortOrder: true
          },
          orderBy: { sortOrder: 'asc' }
        },
        _count: {
          select: {
            menuItems: true
          }
        }
      },
      orderBy: [
        { sortOrder: 'asc' },
        { createdAt: 'asc' }
      ]
    })

    return NextResponse.json({ categories })
  } catch (error) {
    console.error('Get categories error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// POST /api/categories - Create category
export async function POST(request: NextRequest) {
  try {
    const user = await requirePermission(request, 'menu:write')
    if (user instanceof NextResponse) return user

    const body = await request.json()
    const { branchId, ...data } = categorySchema.parse(body)

    if (!branchId) {
      return NextResponse.json(
        { error: 'Branch ID required' },
        { status: 400 }
      )
    }

    // Check if user has access to this branch
    const userBranchIds = user.branches.map(ub => ub.branch.id)
    if (!userBranchIds.includes(branchId) && !hasPermission(user, 'menu:write:all')) {
      return NextResponse.json(
        { error: 'Insufficient permissions for this branch' },
        { status: 403 }
      )
    }

    const category = await db.category.create({
      data: {
        branchId,
        ...data
      },
      include: {
        menuItems: {
          where: { isActive: true },
          orderBy: { sortOrder: 'asc' }
        }
      }
    })

    return NextResponse.json({
      message: 'Category created successfully',
      category
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid input', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Create category error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// Helper function to check permissions
function hasPermission(user: any, permission: string): boolean {
  return user.roles.some((userRole: any) => 
    userRole.role.permissions.includes(permission)
  )
}