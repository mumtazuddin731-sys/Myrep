import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'
import { z } from 'zod'

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  name: z.string().min(2),
  phone: z.string().optional(),
  restaurantName: z.string().min(2),
  branchName: z.string().min(2),
  branchAddress: z.string().min(5)
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password, name, phone, restaurantName, branchName, branchAddress } = registerSchema.parse(body)

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'User already exists' },
        { status: 400 }
      )
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12)

    // Create restaurant
    const restaurant = await db.restaurant.create({
      data: {
        name: restaurantName,
        settings: {
          currency: 'BDT',
          language: 'en',
          timezone: 'Asia/Dhaka'
        }
      }
    })

    // Create branch
    const branch = await db.branch.create({
      data: {
        restaurantId: restaurant.id,
        name: branchName,
        address: branchAddress,
        settings: {
          currency: 'BDT',
          language: 'en',
          timezone: 'Asia/Dhaka'
        }
      }
    })

    // Create user
    const user = await db.user.create({
      data: {
        email,
        password: hashedPassword,
        name,
        phone,
        roles: {
          create: [
            {
              role: {
                create: {
                  name: 'Restaurant Owner',
                  description: 'Owner of the restaurant with full access',
                  permissions: [
                    'restaurant:read',
                    'restaurant:write',
                    'branch:read',
                    'branch:write',
                    'user:read',
                    'user:write',
                    'menu:read',
                    'menu:write',
                    'order:read',
                    'order:write',
                    'analytics:read',
                    'analytics:write',
                    'addon:read',
                    'addon:write',
                    'theme:read',
                    'theme:write'
                  ],
                  isSystem: true
                }
              }
            }
          ]
        },
        branches: {
          create: {
            branchId: branch.id
          }
        },
        profile: {
          create: {}
        }
      },
      include: {
        roles: {
          include: {
            role: true
          }
        },
        branches: {
          include: {
            branch: true
          }
        },
        profile: true
      }
    })

    // Remove password from response
    const { password: _, ...userWithoutPassword } = user

    // Create default categories
    await db.category.createMany({
      data: [
        { branchId: branch.id, name: 'Appetizers', sortOrder: 1 },
        { branchId: branch.id, name: 'Main Courses', sortOrder: 2 },
        { branchId: branch.id, name: 'Desserts', sortOrder: 3 },
        { branchId: branch.id, name: 'Beverages', sortOrder: 4 }
      ]
    })

    // Create session
    const response = NextResponse.json({
      message: 'Registration successful',
      user: userWithoutPassword
    })

    // Set session cookie
    response.cookies.set('session', JSON.stringify(userWithoutPassword), {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 60 * 60 * 24 * 7 // 7 days
    })

    return response
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid input', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Registration error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}