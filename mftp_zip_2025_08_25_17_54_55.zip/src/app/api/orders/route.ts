import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requirePermission, getActiveBranch } from '@/lib/auth'
import { z } from 'zod'

const orderItemSchema = z.object({
  itemId: z.string(),
  variationId: z.string().optional(),
  quantity: z.number().positive(),
  notes: z.string().optional(),
  addons: z.array(z.string()).optional()
})

const orderSchema = z.object({
  branchId: z.string(),
  tableId: z.string().optional(),
  customerName: z.string().optional(),
  customerPhone: z.string().optional(),
  items: z.array(orderItemSchema).min(1),
  notes: z.string().optional()
})

// GET /api/orders - List orders
export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request)
    if (user instanceof NextResponse) return user

    const { searchParams } = new URL(request.url)
    const branchId = searchParams.get('branchId') || await getActiveBranch(request)
    const tableId = searchParams.get('tableId')
    const status = searchParams.get('status')
    const paymentStatus = searchParams.get('paymentStatus')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')

    if (!branchId) {
      return NextResponse.json(
        { error: 'Branch ID required' },
        { status: 400 }
      )
    }

    // Check if user has access to this branch
    const userBranchIds = user.branches.map(ub => ub.branch.id)
    if (!userBranchIds.includes(branchId) && !hasPermission(user, 'order:read:all')) {
      return NextResponse.json(
        { error: 'Insufficient permissions for this branch' },
        { status: 403 }
      )
    }

    const skip = (page - 1) * limit
    const where: any = { branchId }
    
    if (tableId) where.tableId = tableId
    if (status) where.status = status
    if (paymentStatus) where.paymentStatus = paymentStatus

    const [orders, total] = await Promise.all([
      db.order.findMany({
        where,
        include: {
          branch: {
            select: {
              id: true,
              name: true
            }
          },
          table: {
            select: {
              id: true,
              number: true,
              capacity: true
            }
          },
          user: {
            select: {
              id: true,
              name: true,
              email: true
            }
          },
          creator: {
            select: {
              id: true,
              name: true
            }
          },
          items: {
            include: {
              item: {
                select: {
                  id: true,
                  name: true,
                  price: true
                }
              },
              variation: {
                select: {
                  id: true,
                  name: true,
                  price: true
                }
              }
            },
            orderBy: { createdAt: 'asc' }
          }
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' }
      }),
      db.order.count({ where })
    ])

    return NextResponse.json({
      orders,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('Get orders error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// POST /api/orders - Create order
export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth(request)
    if (user instanceof NextResponse) return user

    const body = await request.json()
    const { items, ...data } = orderSchema.parse(body)

    if (!data.branchId) {
      return NextResponse.json(
        { error: 'Branch ID required' },
        { status: 400 }
      )
    }

    // Check if user has access to this branch
    const userBranchIds = user.branches.map(ub => ub.branch.id)
    if (!userBranchIds.includes(data.branchId) && !hasPermission(user, 'order:write:all')) {
      return NextResponse.json(
        { error: 'Insufficient permissions for this branch' },
        { status: 403 }
      )
    }

    // Verify table belongs to branch if provided
    if (data.tableId) {
      const table = await db.table.findFirst({
        where: {
          id: data.tableId,
          branchId: data.branchId
        }
      })

      if (!table) {
        return NextResponse.json(
          { error: 'Table not found in this branch' },
          { status: 404 }
        )
      }
    }

    // Calculate total amount and validate items
    let totalAmount = 0
    const orderItems = []

    for (const itemData of items) {
      const menuItem = await db.menuItem.findFirst({
        where: {
          id: itemData.itemId,
          branchId: data.branchId,
          isActive: true,
          isAvailable: true
        }
      })

      if (!menuItem) {
        return NextResponse.json(
          { error: `Menu item not found or unavailable: ${itemData.itemId}` },
          { status: 404 }
        )
      }

      let unitPrice = menuItem.price

      // Check if variation exists and belongs to the item
      if (itemData.variationId) {
        const variation = await db.itemVariation.findFirst({
          where: {
            id: itemData.variationId,
            itemId: itemData.itemId,
            isActive: true
          }
        })

        if (!variation) {
          return NextResponse.json(
            { error: `Variation not found or unavailable: ${itemData.variationId}` },
            { status: 404 }
          )
        }

        unitPrice = variation.price
      }

      const totalPrice = unitPrice * itemData.quantity
      totalAmount += totalPrice

      orderItems.push({
        itemId: itemData.itemId,
        variationId: itemData.variationId,
        quantity: itemData.quantity,
        unitPrice,
        totalPrice,
        notes: itemData.notes,
        addons: itemData.addons || []
      })
    }

    // Create the order
    const order = await db.order.create({
      data: {
        branchId: data.branchId,
        tableId: data.tableId,
        userId: user.id,
        customerName: data.customerName,
        customerPhone: data.customerPhone,
        totalAmount,
        currency: 'BDT',
        notes: data.notes,
        createdBy: user.id,
        items: {
          create: orderItems
        }
      },
      include: {
        branch: {
          select: {
            id: true,
            name: true
          }
        },
        table: {
          select: {
            id: true,
            number: true
          }
        },
        user: {
          select: {
            id: true,
            name: true
          }
        },
        creator: {
          select: {
            id: true,
            name: true
          }
        },
        items: {
          include: {
            item: {
              select: {
                id: true,
                name: true,
                price: true
              }
            },
            variation: {
              select: {
                id: true,
                name: true,
                price: true
              }
            }
          }
        }
      }
    })

    return NextResponse.json({
      message: 'Order created successfully',
      order
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid input', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Create order error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// Helper function to check permissions
function hasPermission(user: any, permission: string): boolean {
  return user.roles.some((userRole: any) => 
    userRole.role.permissions.includes(permission)
  )
}