import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, requirePermission, getActiveBranch } from '@/lib/auth'
import { z } from 'zod'

const menuItemSchema = z.object({
  categoryId: z.string(),
  name: z.string().min(2),
  description: z.string().optional(),
  image: z.string().url().optional(),
  price: z.number().positive(),
  currency: z.string().default('BDT'),
  isActive: z.boolean().default(true),
  isAvailable: z.boolean().default(true),
  sortOrder: z.number().min(0).default(0),
  nutrition: z.object({}).optional(),
  allergens: z.array(z.string()).optional()
})

const variationSchema = z.object({
  name: z.string().min(2),
  description: z.string().optional(),
  price: z.number().positive(),
  isActive: z.boolean().default(true)
})

const addonSchema = z.object({
  name: z.string().min(2),
  description: z.string().optional(),
  price: z.number().min(0),
  isActive: z.boolean().default(true)
})

// GET /api/menu-items - List menu items
export async function GET(request: NextRequest) {
  try {
    const user = await requireAuth(request)
    if (user instanceof NextResponse) return user

    const { searchParams } = new URL(request.url)
    const branchId = searchParams.get('branchId') || await getActiveBranch(request)
    const categoryId = searchParams.get('categoryId')
    const includeInactive = searchParams.get('includeInactive') === 'true'
    const search = searchParams.get('search') || ''
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '50')

    if (!branchId) {
      return NextResponse.json(
        { error: 'Branch ID required' },
        { status: 400 }
      )
    }

    // Check if user has access to this branch
    const userBranchIds = user.branches.map(ub => ub.branch.id)
    if (!userBranchIds.includes(branchId) && !hasPermission(user, 'menu:read:all')) {
      return NextResponse.json(
        { error: 'Insufficient permissions for this branch' },
        { status: 403 }
      )
    }

    const skip = (page - 1) * limit
    const where: any = { branchId }
    
    if (categoryId) {
      where.categoryId = categoryId
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } }
      ]
    }

    if (!includeInactive) {
      where.isActive = true
    }

    const [menuItems, total] = await Promise.all([
      db.menuItem.findMany({
        where,
        include: {
          category: {
            select: {
              id: true,
              name: true
            }
          },
          variations: {
            where: { isActive: true },
            orderBy: { createdAt: 'asc' }
          },
          addons: {
            where: { isActive: true },
            orderBy: { createdAt: 'asc' }
          }
        },
        skip,
        take: limit,
        orderBy: [
          { sortOrder: 'asc' },
          { createdAt: 'asc' }
        ]
      }),
      db.menuItem.count({ where })
    ])

    return NextResponse.json({
      menuItems,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('Get menu items error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// POST /api/menu-items - Create menu item
export async function POST(request: NextRequest) {
  try {
    const user = await requirePermission(request, 'menu:write')
    if (user instanceof NextResponse) return user

    const body = await request.json()
    const { branchId, variations, addons, ...data } = menuItemSchema.parse(body)

    if (!branchId) {
      return NextResponse.json(
        { error: 'Branch ID required' },
        { status: 400 }
      )
    }

    // Check if user has access to this branch
    const userBranchIds = user.branches.map(ub => ub.branch.id)
    if (!userBranchIds.includes(branchId) && !hasPermission(user, 'menu:write:all')) {
      return NextResponse.json(
        { error: 'Insufficient permissions for this branch' },
        { status: 403 }
      )
    }

    // Verify category belongs to the branch
    const category = await db.category.findFirst({
      where: {
        id: data.categoryId,
        branchId
      }
    })

    if (!category) {
      return NextResponse.json(
        { error: 'Category not found in this branch' },
        { status: 404 }
      )
    }

    const menuItem = await db.menuItem.create({
      data: {
        branchId,
        ...data,
        variations: variations ? {
          create: variations.map((v: any) => ({
            name: v.name,
            description: v.description,
            price: v.price,
            isActive: v.isActive ?? true
          }))
        } : undefined,
        addons: addons ? {
          create: addons.map((a: any) => ({
            name: a.name,
            description: a.description,
            price: a.price,
            isActive: a.isActive ?? true
          }))
        } : undefined
      },
      include: {
        category: {
          select: {
            id: true,
            name: true
          }
        },
        variations: {
          where: { isActive: true },
          orderBy: { createdAt: 'asc' }
        },
        addons: {
          where: { isActive: true },
          orderBy: { createdAt: 'asc' }
        }
      }
    })

    return NextResponse.json({
      message: 'Menu item created successfully',
      menuItem
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid input', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Create menu item error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// Helper function to check permissions
function hasPermission(user: any, permission: string): boolean {
  return user.roles.some((userRole: any) => 
    userRole.role.permissions.includes(permission)
  )
}