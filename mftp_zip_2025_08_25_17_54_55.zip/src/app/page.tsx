'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  QrCode, 
  Users, 
  ChefHat, 
  Settings, 
  BarChart3, 
  Smartphone, 
  Clock,
  Star,
  Shield,
  Zap
} from 'lucide-react'

export default function Home() {
  const features = [
    {
      icon: QrCode,
      title: 'QR Code Menu',
      description: 'Contactless digital menu access with table-specific QR codes'
    },
    {
      icon: Smartphone,
      title: 'Mobile First',
      description: 'Optimized for smartphones with intuitive user experience'
    },
    {
      icon: Users,
      title: 'Multi-Branch Support',
      description: 'Centralized management for multiple restaurant locations'
    },
    {
      icon: BarChart3,
      title: 'Advanced Analytics',
      description: 'Real-time insights and comprehensive reporting system'
    },
    {
      icon: ChefHat,
      title: 'Role-Based Access',
      description: 'Customized interfaces for owners, managers, chefs, and staff'
    },
    {
      icon: Settings,
      title: 'Add-On System',
      description: 'Extensible platform with modular feature enhancements'
    },
    {
      icon: Clock,
      title: 'Real-Time Updates',
      description: 'Instant order status updates and service requests'
    },
    {
      icon: Shield,
      title: 'Secure & Reliable',
      description: 'Enterprise-grade security with 99.9% uptime guarantee'
    }
  ]

  const userRoles = [
    {
      title: 'Restaurant Owner',
      description: 'Complete oversight of all branches with comprehensive analytics',
      color: 'bg-blue-100 text-blue-800'
    },
    {
      title: 'Manager',
      description: 'Regional supervision and staff management capabilities',
      color: 'bg-green-100 text-green-800'
    },
    {
      title: 'Branch Manager',
      description: 'Single branch operations and local team coordination',
      color: 'bg-purple-100 text-purple-800'
    },
    {
      title: 'Chef',
      description: 'Menu management and kitchen order coordination',
      color: 'bg-orange-100 text-orange-800'
    },
    {
      title: 'Waiter',
      description: 'Order management and customer service tools',
      color: 'bg-pink-100 text-pink-800'
    },
    {
      title: 'Restaurant Staff',
      description: 'Essential operational tools and task management',
      color: 'bg-gray-100 text-gray-800'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-r from-emerald-600 to-teal-700 text-white">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative container mx-auto px-4 py-24 md:py-32">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="bg-white p-4 rounded-full">
                <QrCode className="h-12 w-12 text-emerald-600" />
              </div>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Advanced QR Menu System
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-emerald-100 max-w-3xl mx-auto">
              Transform your restaurant experience with digital menus, real-time ordering, 
              and comprehensive management tools for multi-branch operations
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-emerald-700 hover:bg-gray-100">
                Get Started
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-emerald-700">
                View Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">
              Powerful Features for Modern Restaurants
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Everything you need to streamline operations, enhance customer experience, and boost revenue
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-center mb-4">
                    <div className="p-3 bg-emerald-100 rounded-full">
                      <feature.icon className="h-8 w-8 text-emerald-600" />
                    </div>
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Role-Based Access Section */}
      <section className="py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">
              Role-Based Access Control
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Customized interfaces and permissions for every team member
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {userRoles.map((role, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl">{role.title}</CardTitle>
                    <Badge className={role.color}>
                      <Users className="h-4 w-4 mr-1" />
                      Role
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600">
                    {role.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Advanced Features Section */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">
              Advanced Capabilities
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Enterprise-grade features designed for growth and scalability
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-bold mb-6 text-gray-900">Add-On Architecture</h3>
              <p className="text-gray-600 mb-6">
                Extend functionality without modifying core code. Our modular add-on system allows 
                you to integrate new features seamlessly, from payment gateways to loyalty programs.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Zap className="h-5 w-5 text-emerald-600" />
                  <span className="text-gray-700">One-click installation</span>
                </div>
                <div className="flex items-center gap-3">
                  <Shield className="h-5 w-5 text-emerald-600" />
                  <span className="text-gray-700">Secure and tested add-ons</span>
                </div>
                <div className="flex items-center gap-3">
                  <Settings className="h-5 w-5 text-emerald-600" />
                  <span className="text-gray-700">Custom configuration options</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-2xl font-bold mb-6 text-gray-900">Theme Customization</h3>
              <p className="text-gray-600 mb-6">
                Create a unique brand experience with our powerful theme system. Customize colors, 
                layouts, and design elements to match your restaurant's identity perfectly.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Star className="h-5 w-5 text-emerald-600" />
                  <span className="text-gray-700">Multiple pre-designed themes</span>
                </div>
                <div className="flex items-center gap-3">
                  <Settings className="h-5 w-5 text-emerald-600" />
                  <span className="text-gray-700">Drag-and-drop customization</span>
                </div>
                <div className="flex items-center gap-3">
                  <Smartphone className="h-5 w-5 text-emerald-600" />
                  <span className="text-gray-700">Mobile-responsive designs</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-emerald-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Transform Your Restaurant?
          </h2>
          <p className="text-xl mb-8 text-emerald-100 max-w-2xl mx-auto">
            Join hundreds of restaurants across Bangladesh using our advanced QR menu system
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-white text-emerald-700 hover:bg-gray-100">
              Start Free Trial
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-emerald-700">
              Schedule Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <QrCode className="h-8 w-8 text-emerald-400" />
                <span className="text-xl font-bold">QRMenu Pro</span>
              </div>
              <p className="text-gray-400">
                Advanced digital menu solution for modern restaurants
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Features</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Digital Menus</li>
                <li>Order Management</li>
                <li>Analytics</li>
                <li>Multi-Branch Support</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Documentation</li>
                <li>API Reference</li>
                <li>Contact Support</li>
                <li>Status Page</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Connect</h3>
              <ul className="space-y-2 text-gray-400">
                <li>support@qrmenu.pro</li>
                <li>+880 1234-567890</li>
                <li>Dhaka, Bangladesh</li>
              </ul>
            </div>
          </div>
          
          <Separator className="my-8 bg-gray-700" />
          
          <div className="text-center text-gray-400">
            <p>&copy; 2024 QRMenu Pro. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}