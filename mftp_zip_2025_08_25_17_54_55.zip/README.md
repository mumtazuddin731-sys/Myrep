# Advanced QR Menu System

A comprehensive digital menu solution for multi-branch restaurants in Bangladesh, featuring QR code-based ordering, role-based access control, and advanced analytics.

## 🌟 Features

### Core Features
- **QR Code Digital Menu** - Contactless menu access with table-specific QR codes
- **Multi-Branch Support** - Centralized management for multiple restaurant locations
- **Role-Based Access Control** - Customized interfaces for owners, managers, chefs, and staff
- **Real-Time Order Management** - Instant order tracking and status updates
- **Service Request System** - Call waiter, request bill, water requests, and more

### Advanced Features
- **Add-On Architecture** - Modular feature extensions without core code changes
- **Theme Customization** - Complete brand experience customization
- **Analytics Dashboard** - Comprehensive reporting and insights
- **Guest Order Support** - Allow customers to order without registration
- **Mobile-First Design** - Optimized for smartphones and tablets

### User Roles
- **Super Admin** - Hidden administrative control with full system access
- **Restaurant Owner** - Multi-branch oversight and financial reports
- **Manager** - Regional supervision and staff management
- **Branch Manager** - Single branch operations and local team coordination
- **Chef** - Menu management and kitchen order coordination
- **Waiter** - Order management and customer service tools
- **Restaurant Staff** - Essential operational tools and task management

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd advanced-qr-menu-system
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   ```
   Edit `.env` with your configuration:
   ```env
   DATABASE_URL="file:./dev.db"
   NEXTAUTH_URL="http://localhost:3000"
   NEXTAUTH_SECRET="your-super-secret-key"
   ```

4. **Set up database**
   ```bash
   npm run db:push
   npm run db:generate
   ```

5. **Start development server**
   ```bash
   npm run dev
   ```

6. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

## 📁 Project Structure

```
├── prisma/
│   └── schema.prisma              # Database schema
├── src/
│   ├── app/
│   │   ├── api/                   # API routes
│   │   │   ├── auth/              # Authentication endpoints
│   │   │   ├── restaurants/       # Restaurant management
│   │   │   ├── branches/          # Branch management
│   │   │   ├── categories/        # Menu categories
│   │   │   ├── menu-items/        # Menu items
│   │   │   ├── orders/            # Order management
│   │   │   ├── service-requests/  # Service requests
│   │   │   └── public/            # Public customer APIs
│   │   ├── layout.tsx             # Root layout
│   │   └── page.tsx               # Landing page
│   ├── components/
│   │   └── ui/                    # shadcn/ui components
│   ├── hooks/                     # Custom React hooks
│   └── lib/
│       ├── auth.ts                # Authentication utilities
│       ├── db.ts                  # Database connection
│       ├── socket.ts              # Socket.IO configuration
│       └── utils.ts               # Utility functions
├── public/                        # Static assets
├── db/                           # Database files
├── components.json                # shadcn/ui config
├── tailwind.config.ts             # Tailwind CSS config
├── tsconfig.json                  # TypeScript config
├── next.config.ts                 # Next.js config
└── package.json                   # Dependencies and scripts
```

## 🛠️ Development

### Available Scripts

```bash
# Development
npm run dev          # Start development server
npm run build        # Build for production
npm run start        # Start production server
npm run lint         # Run ESLint

# Database
npm run db:push      # Push schema to database
npm run db:generate  # Generate Prisma client
npm run db:migrate   # Run database migrations
npm run db:reset     # Reset database
```

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `DATABASE_URL` | Database connection string | `file:./dev.db` |
| `NEXTAUTH_URL` | Application URL | `http://localhost:3000` |
| `NEXTAUTH_SECRET` | JWT secret key | Required |

## 🚀 Deployment

### Vercel (Recommended)

1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Ready for deployment"
   git push origin main
   ```

2. **Deploy to Vercel**
   - Connect your GitHub repository to Vercel
   - Configure environment variables
   - Deploy automatically

3. **Production Database**
   - Use Vercel Postgres or external database
   - Update `DATABASE_URL` in production environment
   - Run database migrations

### Environment Variables for Production

```env
DATABASE_URL="postgresql://user:password@host:port/database"
NEXTAUTH_URL="https://your-app.vercel.app"
NEXTAUTH_SECRET="your-production-secret-key"
NODE_ENV="production"
```

## 📊 Database Schema

The application uses a comprehensive database schema with the following main entities:

- **Users & Authentication** - User management with role-based access
- **Restaurants & Branches** - Multi-branch restaurant structure
- **Menu Management** - Categories, items, variations, and addons
- **Order System** - Order processing and tracking
- **Service Requests** - Customer service management
- **Analytics** - Performance and usage metrics
- **Add-ons & Themes** - Extensible architecture

## 🔧 Technologies Used

### Frontend
- **Next.js 15** - React framework with App Router
- **TypeScript** - Type-safe JavaScript
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn/ui** - Modern UI component library
- **Lucide React** - Beautiful icons
- **Framer Motion** - Animation library

### Backend
- **Next.js API Routes** - Serverless API endpoints
- **Prisma ORM** - Database toolkit
- **SQLite/PostgreSQL** - Database
- **bcryptjs** - Password hashing
- **Zod** - Schema validation
- **Socket.IO** - Real-time communication

### Development Tools
- **ESLint** - Code linting
- **Prettier** - Code formatting
- **Tailwind CSS** - Styling
- **TypeScript** - Type safety

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
- Create an issue in the GitHub repository
- Email: support@qrmenu.pro
- Documentation: [docs.qrmenu.pro](https://docs.qrmenu.pro)

## 🏆 Acknowledgments

- Built with ❤️ for restaurants in Bangladesh
- Powered by Next.js and modern web technologies
- Special thanks to the open-source community

---

**QRMenu Pro** - Transforming restaurant experiences, one QR code at a time. 🇧🇩