# API Documentation

## Overview

The Advanced QR Menu System provides a comprehensive REST API for managing restaurants, branches, menus, orders, and service requests. The API is built with Next.js API Routes and follows RESTful conventions.

## Base URL

```
Development: http://localhost:3000/api
Production: https://your-domain.com/api
```

## Authentication

Most API endpoints require authentication using session-based authentication. After logging in, a session cookie is set that must be included in subsequent requests.

### Authentication Flow

1. **Login**: `POST /auth/login`
2. **Session Management**: Session cookie is automatically included in requests
3. **Logout**: `POST /auth/logout`

## Response Format

All API responses follow this format:

```json
{
  "message": "Success message",
  "data": {},
  "error": null
}
```

Error responses:
```json
{
  "error": "Error message",
  "details": []
}
```

## Endpoints

### Authentication

#### POST /auth/login
Authenticate user and create session.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "message": "Login successful",
  "user": {
    "id": "user_id",
    "email": "user@example.com",
    "name": "User Name",
    "roles": [...],
    "branches": [...]
  }
}
```

#### POST /auth/logout
Terminate user session.

**Response:**
```json
{
  "message": "Logout successful"
}
```

#### POST /auth/register
Register new restaurant and create owner account.

**Request Body:**
```json
{
  "email": "owner@example.com",
  "password": "password123",
  "name": "Restaurant Owner",
  "phone": "+8801234567890",
  "restaurantName": "My Restaurant",
  "branchName": "Main Branch",
  "branchAddress": "123 Street, City"
}
```

### Restaurants

#### GET /restaurants
List restaurants with pagination.

**Query Parameters:**
- `page` (number): Page number (default: 1)
- `limit` (number): Items per page (default: 10)
- `search` (string): Search term

**Response:**
```json
{
  "restaurants": [...],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 25,
    "pages": 3
  }
}
```

#### POST /restaurants
Create new restaurant.

**Request Body:**
```json
{
  "name": "Restaurant Name",
  "description": "Restaurant description",
  "phone": "+8801234567890",
  "email": "restaurant@example.com",
  "address": "123 Street, City",
  "settings": {}
}
```

### Branches

#### GET /branches
List branches with pagination.

**Query Parameters:**
- `page` (number): Page number (default: 1)
- `limit` (number): Items per page (default: 10)
- `search` (string): Search term
- `restaurantId` (string): Filter by restaurant

**Response:**
```json
{
  "branches": [...],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 15,
    "pages": 2
  }
}
```

#### POST /branches
Create new branch.

**Request Body:**
```json
{
  "restaurantId": "restaurant_id",
  "name": "Branch Name",
  "address": "123 Street, City",
  "phone": "+8801234567890",
  "latitude": 23.8103,
  "longitude": 90.4125,
  "settings": {}
}
```

### Menu Categories

#### GET /categories
List categories for a branch.

**Query Parameters:**
- `branchId` (string): Branch ID (required)
- `includeInactive` (boolean): Include inactive categories (default: false)
- `search` (string): Search term

**Response:**
```json
{
  "categories": [
    {
      "id": "category_id",
      "name": "Appetizers",
      "description": "Start your meal with these",
      "sortOrder": 1,
      "menuItems": [...]
    }
  ]
}
```

#### POST /categories
Create new category.

**Request Body:**
```json
{
  "branchId": "branch_id",
  "name": "Category Name",
  "description": "Category description",
  "sortOrder": 1,
  "isActive": true
}
```

### Menu Items

#### GET /menu-items
List menu items for a branch.

**Query Parameters:**
- `branchId` (string): Branch ID (required)
- `categoryId` (string): Filter by category
- `includeInactive` (boolean): Include inactive items (default: false)
- `search` (string): Search term
- `page` (number): Page number (default: 1)
- `limit` (number): Items per page (default: 50)

**Response:**
```json
{
  "menuItems": [
    {
      "id": "item_id",
      "name": "Item Name",
      "description": "Item description",
      "price": 100,
      "currency": "BDT",
      "isActive": true,
      "isAvailable": true,
      "category": {...},
      "variations": [...],
      "addons": [...]
    }
  ],
  "pagination": {...}
}
```

#### POST /menu-items
Create new menu item.

**Request Body:**
```json
{
  "branchId": "branch_id",
  "categoryId": "category_id",
  "name": "Item Name",
  "description": "Item description",
  "price": 100,
  "variations": [
    {
      "name": "Large",
      "price": 150
    }
  ],
  "addons": [
    {
      "name": "Extra Cheese",
      "price": 20
    }
  ]
}
```

### Orders

#### GET /orders
List orders with filtering.

**Query Parameters:**
- `branchId` (string): Branch ID
- `tableId` (string): Filter by table
- `status` (string): Filter by status (PENDING, CONFIRMED, PREPARING, READY, SERVED, COMPLETED, CANCELLED)
- `paymentStatus` (string): Filter by payment status (PENDING, PAID, REFUNDED, FAILED)
- `page` (number): Page number (default: 1)
- `limit` (number): Items per page (default: 20)

**Response:**
```json
{
  "orders": [
    {
      "id": "order_id",
      "status": "PENDING",
      "totalAmount": 250,
      "currency": "BDT",
      "paymentStatus": "PENDING",
      "branch": {...},
      "table": {...},
      "user": {...},
      "items": [...]
    }
  ],
  "pagination": {...}
}
```

#### POST /orders
Create new order.

**Request Body:**
```json
{
  "branchId": "branch_id",
  "tableId": "table_id",
  "customerName": "John Doe",
  "customerPhone": "+8801234567890",
  "items": [
    {
      "itemId": "item_id",
      "variationId": "variation_id",
      "quantity": 2,
      "notes": "Extra spicy",
      "addons": ["addon_id"]
    }
  ],
  "notes": "Order notes"
}
```

### Service Requests

#### GET /service-requests
List service requests.

**Query Parameters:**
- `branchId` (string): Branch ID
- `tableId` (string): Filter by table
- `type` (string): Filter by type (CALL_WAITER, REQUEST_BILL, WATER_REQUEST, CLEANING_REQUEST, OTHER)
- `status` (string): Filter by status (PENDING, IN_PROGRESS, COMPLETED, CANCELLED)
- `page` (number): Page number (default: 1)
- `limit` (number): Items per page (default: 20)

**Response:**
```json
{
  "serviceRequests": [
    {
      "id": "request_id",
      "type": "CALL_WAITER",
      "status": "PENDING",
      "notes": "Need assistance",
      "branch": {...},
      "table": {...},
      "user": {...}
    }
  ],
  "pagination": {...}
}
```

#### POST /service-requests
Create new service request.

**Request Body:**
```json
{
  "branchId": "branch_id",
  "tableId": "table_id",
  "type": "CALL_WAITER",
  "notes": "Customer needs assistance"
}
```

#### PATCH /service-requests/[id]
Update service request status.

**Request Body:**
```json
{
  "status": "IN_PROGRESS"
}
```

### Public API (No Authentication Required)

#### GET /public/menu
Get public menu for QR code access.

**Query Parameters:**
- `branchId` (string): Branch ID (required)
- `tableId` (string): Table ID (optional)

**Response:**
```json
{
  "branch": {...},
  "restaurant": {...},
  "table": {...},
  "categories": [...],
  "settings": {
    "currency": "BDT",
    "allowGuestOrders": true,
    "enableServiceRequests": true
  }
}
```

#### POST /public/menu
Submit guest order.

**Request Body:**
```json
{
  "branchId": "branch_id",
  "tableId": "table_id",
  "customerName": "John Doe",
  "customerPhone": "+8801234567890",
  "items": [...],
  "notes": "Order notes"
}
```

#### POST /public/service-requests
Create guest service request.

**Request Body:**
```json
{
  "branchId": "branch_id",
  "tableId": "table_id",
  "type": "CALL_WAITER",
  "notes": "Need assistance"
}
```

## Error Codes

| Status Code | Description |
|-------------|-------------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not Found |
| 422 | Validation Error |
| 500 | Internal Server Error |

## Rate Limiting

API endpoints are rate-limited to prevent abuse:
- Auth endpoints: 5 requests per minute
- Public endpoints: 60 requests per minute
- Protected endpoints: 120 requests per minute

## Webhooks

The system supports webhooks for real-time notifications:
- Order created
- Order status changed
- Service request created
- Service request status changed

Configure webhook URLs in the restaurant settings.

## SDK Integration

### JavaScript/TypeScript

```typescript
// Login
const loginResponse = await fetch('/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password })
})

// Get menu
const menuResponse = await fetch('/api/public/menu?branchId=branch_id')
const menu = await menuResponse.json()

// Create order
const orderResponse = await fetch('/api/orders', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(orderData)
})
```

### cURL

```bash
# Login
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"password123"}'

# Get menu
curl "http://localhost:3000/api/public/menu?branchId=branch_id"

# Create order
curl -X POST http://localhost:3000/api/orders \
  -H "Content-Type: application/json" \
  -d '{"branchId":"branch_id","items":[...]}'
```

## Testing

Use the provided seed data for testing:
- Email: `owner@demo.com`
- Password: `password123`
- Branch ID: Available after seeding
- Table IDs: Available after seeding