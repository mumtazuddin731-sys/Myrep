import { db } from '../src/lib/db'
import bcrypt from 'bcryptjs'

async function main() {
  console.log('🌱 Seeding database...')

  // Create a default restaurant
  const restaurant = await db.restaurant.create({
    data: {
      name: 'Demo Restaurant',
      description: 'A sample restaurant for demonstration',
      phone: '+8801234567890',
      email: 'info@demorestaurant.com',
      address: '123 Demo Street, Dhaka, Bangladesh',
      website: 'https://demorestaurant.com',
      settings: {
        currency: 'BDT',
        language: 'en',
        timezone: 'Asia/Dhaka',
        allowGuestOrders: true,
        requireCustomerInfo: false,
        enableServiceRequests: true
      }
    }
  })

  console.log('✅ Restaurant created:', restaurant.name)

  // Create a default branch
  const branch = await db.branch.create({
    data: {
      restaurantId: restaurant.id,
      name: 'Main Branch',
      address: '123 Demo Street, Dhaka 1000',
      phone: '+8801234567890',
      email: 'main@demorestaurant.com',
      latitude: 23.8103,
      longitude: 90.4125,
      settings: {
        currency: 'BDT',
        language: 'en',
        timezone: 'Asia/Dhaka',
        allowGuestOrders: true,
        requireCustomerInfo: false,
        enableServiceRequests: true
      }
    }
  })

  console.log('✅ Branch created:', branch.name)

  // Create default roles
  const roles = await Promise.all([
    db.role.create({
      data: {
        name: 'Super Admin',
        description: 'System administrator with full access',
        permissions: [
          'system:read',
          'system:write',
          'restaurant:read',
          'restaurant:write',
          'branch:read',
          'branch:write',
          'user:read',
          'user:write',
          'menu:read',
          'menu:write',
          'order:read',
          'order:write',
          'analytics:read',
          'analytics:write',
          'addon:read',
          'addon:write',
          'theme:read',
          'theme:write',
          'service:read',
          'service:write'
        ],
        isSystem: true
      }
    }),
    db.role.create({
      data: {
        name: 'Restaurant Owner',
        description: 'Owner of the restaurant with full access',
        permissions: [
          'restaurant:read',
          'restaurant:write',
          'branch:read',
          'branch:write',
          'user:read',
          'user:write',
          'menu:read',
          'menu:write',
          'order:read',
          'order:write',
          'analytics:read',
          'analytics:write',
          'addon:read',
          'addon:write',
          'theme:read',
          'theme:write',
          'service:read',
          'service:write'
        ],
        isSystem: true
      }
    }),
    db.role.create({
      data: {
        name: 'Manager',
        description: 'Restaurant manager with operational access',
        permissions: [
          'branch:read',
          'branch:write',
          'user:read',
          'user:write',
          'menu:read',
          'menu:write',
          'order:read',
          'order:write',
          'analytics:read',
          'service:read',
          'service:write'
        ],
        isSystem: true
      }
    }),
    db.role.create({
      data: {
        name: 'Branch Manager',
        description: 'Branch manager with local operational access',
        permissions: [
          'branch:read',
          'user:read',
          'menu:read',
          'menu:write',
          'order:read',
          'order:write',
          'analytics:read',
          'service:read',
          'service:write'
        ],
        isSystem: true
      }
    }),
    db.role.create({
      data: {
        name: 'Chef',
        description: 'Kitchen staff with menu and order access',
        permissions: [
          'menu:read',
          'menu:write',
          'order:read',
          'service:read'
        ],
        isSystem: true
      }
    }),
    db.role.create({
      data: {
        name: 'Waiter',
        description: 'Wait staff with order and service access',
        permissions: [
          'menu:read',
          'order:read',
          'order:write',
          'service:read',
          'service:write'
        ],
        isSystem: true
      }
    }),
    db.role.create({
      data: {
        name: 'Restaurant Staff',
        description: 'General staff with basic access',
        permissions: [
          'menu:read',
          'order:read',
          'service:read'
        ],
        isSystem: true
      }
    })
  ])

  console.log('✅ Roles created:', roles.length)

  // Create default user (Restaurant Owner)
  const hashedPassword = await bcrypt.hash('password123', 12)
  const user = await db.user.create({
    data: {
      email: 'owner@demo.com',
      password: hashedPassword,
      name: 'Demo Owner',
      phone: '+8801234567890',
      roles: {
        create: [
          {
            roleId: roles[1].id // Restaurant Owner role
          }
        ]
      },
      branches: {
        create: [
          {
            branchId: branch.id
          }
        ]
      },
      profile: {
        create: {
          bio: 'Demo restaurant owner',
          preferences: {
            language: 'en',
            notifications: true
          }
        }
      }
    }
  })

  console.log('✅ User created:', user.email)

  // Create default categories
  const categories = await Promise.all([
    db.category.create({
      data: {
        branchId: branch.id,
        name: 'Appetizers',
        description: 'Start your meal with these delicious appetizers',
        sortOrder: 1
      }
    }),
    db.category.create({
      data: {
        branchId: branch.id,
        name: 'Main Courses',
        description: 'Hearty main courses for a satisfying meal',
        sortOrder: 2
      }
    }),
    db.category.create({
      data: {
        branchId: branch.id,
        name: 'Desserts',
        description: 'Sweet endings to your perfect meal',
        sortOrder: 3
      }
    }),
    db.category.create({
      data: {
        branchId: branch.id,
        name: 'Beverages',
        description: 'Refreshing drinks and beverages',
        sortOrder: 4
      }
    })
  ])

  console.log('✅ Categories created:', categories.length)

  // Create sample menu items
  const menuItems = await Promise.all([
    // Appetizers
    db.menuItem.create({
      data: {
        branchId: branch.id,
        categoryId: categories[0].id,
        name: 'Spring Rolls',
        description: 'Crispy vegetable spring rolls served with sweet chili sauce',
        price: 180,
        currency: 'BDT',
        sortOrder: 1,
        nutrition: {
          calories: 150,
          protein: 3,
          carbs: 20,
          fat: 7
        }
      }
    }),
    db.menuItem.create({
      data: {
        branchId: branch.id,
        categoryId: categories[0].id,
        name: 'Chicken Wings',
        description: 'Spicy chicken wings marinated in special spices',
        price: 280,
        currency: 'BDT',
        sortOrder: 2,
        variations: {
          create: [
            {
              name: '6 Pieces',
              price: 280
            },
            {
              name: '12 Pieces',
              price: 520
            }
          ]
        }
      }
    }),
    // Main Courses
    db.menuItem.create({
      data: {
        branchId: branch.id,
        categoryId: categories[1].id,
        name: 'Chicken Biryani',
        description: 'Aromatic basmati rice cooked with tender chicken and spices',
        price: 350,
        currency: 'BDT',
        sortOrder: 1,
        variations: {
          create: [
            {
              name: 'Regular',
              price: 350
            },
            {
              name: 'Large',
              price: 450
            }
          ]
        }
      }
    }),
    db.menuItem.create({
      data: {
        branchId: branch.id,
        categoryId: categories[1].id,
        name: 'Beef Kebab',
        description: 'Tender beef kebabs grilled to perfection',
        price: 420,
        currency: 'BDT',
        sortOrder: 2,
        addons: {
          create: [
            {
              name: 'Extra Naan',
              price: 30
            },
            {
              name: 'Raita',
              price: 40
            }
          ]
        }
      }
    }),
    // Desserts
    db.menuItem.create({
      data: {
        branchId: branch.id,
        categoryId: categories[2].id,
        name: 'Gulab Jamun',
        description: 'Sweet milk dumplings in rose-flavored syrup',
        price: 120,
        currency: 'BDT',
        sortOrder: 1
      }
    }),
    db.menuItem.create({
      data: {
        branchId: branch.id,
        categoryId: categories[2].id,
        name: 'Rasmalai',
        description: 'Soft cheese patties in sweetened milk',
        price: 150,
        currency: 'BDT',
        sortOrder: 2
      }
    }),
    // Beverages
    db.menuItem.create({
      data: {
        branchId: branch.id,
        categoryId: categories[3].id,
        name: 'Mango Lassi',
        description: 'Refreshing yogurt drink with mango pulp',
        price: 100,
        currency: 'BDT',
        sortOrder: 1
      }
    }),
    db.menuItem.create({
      data: {
        branchId: branch.id,
        categoryId: categories[3].id,
        name: 'Fresh Lime Soda',
        description: 'Freshly squeezed lime with soda water',
        price: 80,
        currency: 'BDT',
        sortOrder: 2,
        variations: {
          create: [
            {
              name: 'Regular',
              price: 80
            },
            {
              name: 'Large',
              price: 120
            }
          ]
        }
      }
    })
  ])

  console.log('✅ Menu items created:', menuItems.length)

  // Create sample tables
  const tables = await Promise.all([
    db.table.create({
      data: {
        branchId: branch.id,
        number: 'T1',
        capacity: 4,
        qrCode: `qr-table-1-${branch.id}`,
        position: { x: 100, y: 100 }
      }
    }),
    db.table.create({
      data: {
        branchId: branch.id,
        number: 'T2',
        capacity: 2,
        qrCode: `qr-table-2-${branch.id}`,
        position: { x: 300, y: 100 }
      }
    }),
    db.table.create({
      data: {
        branchId: branch.id,
        number: 'T3',
        capacity: 6,
        qrCode: `qr-table-3-${branch.id}`,
        position: { x: 100, y: 300 }
      }
    }),
    db.table.create({
      data: {
        branchId: branch.id,
        number: 'T4',
        capacity: 8,
        qrCode: `qr-table-4-${branch.id}`,
        position: { x: 300, y: 300 }
      }
    })
  ])

  console.log('✅ Tables created:', tables.length)

  // Create default theme
  const theme = await db.theme.create({
    data: {
      restaurantId: restaurant.id,
      name: 'Default Theme',
      description: 'Clean and modern default theme',
      config: {
        colors: {
          primary: '#059669',
          secondary: '#0d9488',
          accent: '#10b981',
          background: '#ffffff',
          foreground: '#1f2937'
        },
        fonts: {
          heading: 'Inter',
          body: 'Inter',
          menu: 'Inter'
        },
        layout: {
          style: 'modern',
          spacing: 'comfortable'
        }
      },
      isDefault: true
    }
  })

  console.log('✅ Theme created:', theme.name)

  // Apply theme to branch
  await db.branchTheme.create({
    data: {
      branchId: branch.id,
      themeId: theme.id,
      settings: {}
    }
  })

  console.log('✅ Theme applied to branch')

  console.log('')
  console.log('🎉 Database seeding completed successfully!')
  console.log('')
  console.log('📋 Default Login Credentials:')
  console.log('   Email: owner@demo.com')
  console.log('   Password: password123')
  console.log('')
  console.log('🏢 Restaurant: Demo Restaurant')
  console.log('📍 Branch: Main Branch')
  console.log('🪑 Tables: 4 tables created')
  console.log('📋 Menu Items: 8 items across 4 categories')
  console.log('')
  console.log('You can now start the application with: npm run dev')
}

main()
  .catch((e) => {
    console.error('❌ Error seeding database:', e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })