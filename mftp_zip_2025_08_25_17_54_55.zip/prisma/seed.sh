#!/bin/bash

# Database seed script for Advanced QR Menu System
# This script populates the database with initial data

set -e

echo "🌱 Seeding database with initial data..."
echo "====================================="

# Check if environment file exists
if [ ! -f .env ]; then
    echo "❌ .env file not found. Please run setup.sh first."
    exit 1
fi

# Load environment variables
source .env

# Run the seed script
echo "📝 Running database seed..."
npx tsx prisma/seed.ts

echo "✅ Database seeding complete!"
echo ""
echo "Default credentials:"
echo "- Restaurant: Demo Restaurant"
echo "- Branch: Main Branch"
echo "- Owner Email: owner@demo.com"
echo "- Password: password123"
echo ""
echo "You can now log in and start using the system!"